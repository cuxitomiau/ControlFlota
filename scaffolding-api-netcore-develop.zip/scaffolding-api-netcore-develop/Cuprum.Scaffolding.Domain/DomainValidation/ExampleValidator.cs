﻿using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DomainValidation
{
    /// <summary>
    /// Validador de datos clase ejemplo
    /// </summary>
    public class ExampleValidator : AbstractValidator<ExampleDto>
    {
        /// <summary>
        /// Constructor de validador
        /// </summary>
        public ExampleValidator()
        {
            RuleFor(x => x.Id).GreaterThan(0).WithMessage("El campo Id debe ser mayor a 0.");
        }
    }
}
