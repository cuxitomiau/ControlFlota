﻿using Cuprum.Scaffolding.Domain.Contracts;
using Cuprum.Scaffolding.Domain.DataTransferObject.Error;
using FluentValidation.Results;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DomainValidation
{
    public static class ValidationTools
    {
        /// <summary>
        /// Entrega un listado de errores basado en un objeto generico para errores.
        /// </summary>
        /// <param name="result"></param>
        /// <param name="absolutePath"></param>
        /// <returns>ProblemDetailsModel</returns>
        public static IProblemDetailsModel GetInvalidParams(this IProblemDetailsModel problemDetailModel, ValidationResult result, string absolutePath)
        {
            foreach (var failure in result.Errors)
            {
                problemDetailModel.Title = HttpStatusCode.BadRequest.ToString();
                problemDetailModel.Detail = "Parámetro(s) no válidos.";
                problemDetailModel.Instance = absolutePath;

                problemDetailModel.InvalidParams.Add(
                    new InvalidParamsModel
                    {
                        Name = failure.PropertyName,
                        Reason = failure.ErrorMessage
                    });
            }

            return problemDetailModel;
        }

        /// <summary>
        /// Crea un objeto ProblemDetailModel para errores de tipo Not Found
        /// </summary>
        /// <param name="detail">Detalle del problema</param>
        /// <param name="uri">URI actual</param>
        /// <returns>ProblemDetailsModel</returns>
        public static IProblemDetailsModel GetErrorNotFound(this IProblemDetailsModel problemDetailModel, string detail, string uri)
        {
            problemDetailModel.Title = "Not Found";
            problemDetailModel.Detail = detail;
            problemDetailModel.Instance = uri;

            return problemDetailModel;
        }

        /// <summary>
        /// Crea un objeto problemDetailModel para errores de tipo Internal Server Error
        /// </summary>
        /// <param name="detail">Detalle del problema</param>
        /// <param name="uri">URI actual</param>
        /// <returns>ProblemDetailsModel</returns>
        public static IProblemDetailsModel GetErrorInternalServerError(this IProblemDetailsModel problemDetailModel, string detail, string uri)
        {
            problemDetailModel.Title = "Internal Server Error";
            problemDetailModel.Detail = "Falla a nivel de acceso a datos o aplicación: " + detail;
            problemDetailModel.Instance = uri;

            return problemDetailModel;
        }

        #region [Validación Número Entero]
        /// <summary>
        /// Valida que un número sea mayor que el valor comparado
        /// </summary>
        /// <param name="integer"></param>
        /// <param name="valueToCompare"></param>
        /// <returns></returns>
        public static bool GreaterThan(this int integer, int valueToCompare)
        {
            return integer > valueToCompare;
        }
        #endregion
    }
}
