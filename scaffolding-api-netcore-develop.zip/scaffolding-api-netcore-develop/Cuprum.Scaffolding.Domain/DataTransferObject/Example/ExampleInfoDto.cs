﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DataTransferObject.Example
{
    /// <summary>
    /// Clase ExampleInfoDto, utilizada para entregar información. Aquí se definen las propiedades y lógica de negocio asociada al objeto.
    /// </summary>
    public class ExampleInfoDto
    {
        //Propiedades
        public int Id { get; set; }
        public int MontoTotal { get { return CalcularMontoTotal(); } }

        /// <summary>
        /// Métodos (Lógica de Negocio). Calcula y obtiene el valor del monto total
        /// </summary>
        /// <returns>Monto Total</returns>
        public int CalcularMontoTotal()
        {
            var x = Id;
            var y = 5;
            return x + y;
        }
    }
}
