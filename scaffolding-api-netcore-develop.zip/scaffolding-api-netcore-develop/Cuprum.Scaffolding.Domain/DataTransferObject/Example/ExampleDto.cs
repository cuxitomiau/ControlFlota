﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DataTransferObject.Example
{
    /// <summary>
    /// Clase ExampleDto para utilizar como parámetro.
    /// </summary>
    public class ExampleDto
    {
        public int Id { get; set; }
    }
}
