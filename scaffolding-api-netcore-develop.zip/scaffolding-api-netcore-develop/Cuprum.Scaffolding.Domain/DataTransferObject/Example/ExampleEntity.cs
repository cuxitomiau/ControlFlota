﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DataTransferObject.Example
{
    public class ExampleEntity
    {
        public int IdRegistro { get; set; }
    }
}
