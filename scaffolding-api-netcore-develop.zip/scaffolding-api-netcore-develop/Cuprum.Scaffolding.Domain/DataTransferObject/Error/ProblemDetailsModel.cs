﻿using Cuprum.Scaffolding.Domain.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DataTransferObject.Error
{
    /// <summary>
    /// Clase para estandarizar mensajes de error.
    /// </summary>
    public class ProblemDetailsModel : IProblemDetailsModel
    {
        /// <summary>
        /// Título que identifica el problema
        /// </summary>
        public string Title { get; set; }
        
        /// <summary>
        /// Detalle del problema
        /// </summary>
        public string Detail { get; set; }

        /// <summary>
        /// Referencia URI que identifica la ocurrencia específica del problema
        /// </summary>
        public string Instance { get; set; }

        /// <summary>
        /// Listado de parámetros inválidos
        /// </summary>
        public List<InvalidParamsModel> InvalidParams { get; set; }

        /// <summary>
        /// Contructor de la clase
        /// </summary>
        public ProblemDetailsModel()
        {
            InvalidParams = new List<InvalidParamsModel>();
        }
    }
}
