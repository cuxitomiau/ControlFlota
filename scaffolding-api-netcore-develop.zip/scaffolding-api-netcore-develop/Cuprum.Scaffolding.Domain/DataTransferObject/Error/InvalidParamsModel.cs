﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.DataTransferObject.Error
{
    /// <summary>
    /// Clase que especifica un parámetro inválido
    /// </summary>
    public class InvalidParamsModel
    {
        /// <summary>
        /// Nombre del parámetro
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Razón del parámetro inválido
        /// </summary>
        public string Reason { get; set; }
    }
}
