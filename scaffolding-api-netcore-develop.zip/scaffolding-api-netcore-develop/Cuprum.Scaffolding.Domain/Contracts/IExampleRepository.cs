﻿using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.Contracts
{
    /// <summary>
    /// Interfaz de ExampleRepository
    /// </summary>
    public interface IExampleRepository
    {
        ExampleInfoDto FindById(int id);
        int Create(ExampleDto example);
        bool Update(ExampleDto example);
    }
}
