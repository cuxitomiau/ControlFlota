﻿using Cuprum.Scaffolding.Domain.DataTransferObject.Error;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Domain.Contracts
{
    public interface IProblemDetailsModel
    {
        /// <summary>
        /// Título que identifica el problema
        /// </summary>
        string Title { get; set; }

        /// <summary>
        /// Detalle del problema
        /// </summary>
        string Detail { get; set; }

        /// <summary>
        /// Referencia URI que identifica la ocurrencia específica del problema
        /// </summary>
        string Instance { get; set; }

        /// <summary>
        /// Listado de parámetros inválidos
        /// </summary>
        List<InvalidParamsModel> InvalidParams { get; set; }
    }
}
