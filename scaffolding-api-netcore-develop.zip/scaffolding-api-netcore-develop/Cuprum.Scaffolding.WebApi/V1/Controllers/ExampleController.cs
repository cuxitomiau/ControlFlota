﻿using Cuprum.Scaffolding.Domain.Contracts;
using Cuprum.Scaffolding.Domain.DataTransferObject.Error;
using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using Cuprum.Scaffolding.Domain.DomainValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;

namespace Cuprum.Scaffolding.WebApi.V1.Controllers
{
    /// <summary>
    /// Controlador API Example
    /// </summary>
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/example")]
    [Produces("application/json")]
    [ApiController]
    public class ExampleController : ControllerBase
    {
        private readonly IExampleRepository _exampleRepository;
        private readonly IProblemDetailsModel _problemDetailModel;

        /// <summary>
        /// Constructor. Se inicializan las dependencias registradas
        /// </summary>
        public ExampleController(IExampleRepository exampleRepository, IProblemDetailsModel problemDetailModel)
        {
            _exampleRepository = exampleRepository;
            _problemDetailModel = problemDetailModel;
        }

        /// <summary>
        /// Método que obtiene un ejemplo por id
        /// </summary>
        /// <param name="id">identificador de un objeto ejemplo.</param>
        /// <response code="200">OK - Retorna objeto de tipo Example.</response>
        /// <response code="404">Not Found - No se encontraron resultados para el id consultado.</response>
        /// <response code="500">Internal Server Error - Falla a nivel de acceso a datos o aplicación.</response>
        /// <returns>ExampleInfoDto</returns>
        [HttpGet()]
        [Route("{id}")]
        [ProducesResponseType(typeof(ExampleInfoDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status500InternalServerError)]
        public ActionResult<ExampleInfoDto> Get(int id)
        {
            try
            {
                //Se utiliza repository para buscar un registro
                var example = _exampleRepository.FindById(id);
                if (example != null)
                {
                    return Ok(example);
                }
                else
                {
                    //En caso de no encontrar un registro, se indica error Not Found
                    return NotFound(_problemDetailModel.GetErrorNotFound(
                        "No se encontraron resultados para el id consultado",
                        HttpContext.Request.Path));
                }
            }
            catch (Exception ex)
            {
                var problemDetailModel = _problemDetailModel.GetErrorInternalServerError(ex.Message, HttpContext.Request.Path);
                return StatusCode(StatusCodes.Status500InternalServerError, problemDetailModel);
            }
        }

        /// <summary>
        /// Método que crea un ejemplo
        /// </summary>
        /// <param name="example">Objeto ejemplo a crear.</param>
        /// <response code="201">Created - Retorna el id del nuevo objeto ejemplo creado.</response>
        /// <response code="400">Bad Request - Datos enviados no son válidos.</response>
        /// <response code="500">Internal Server Error - Falla a nivel de acceso a datos o aplicación.</response>
        /// <returns>Retorna el id del objeto ejemplo creado.</returns>
        [HttpPost]
        [ProducesResponseType(typeof(int), StatusCodes.Status201Created)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status500InternalServerError)]
        public ActionResult<int> Post([FromBody]ExampleDto example)
        {
            try
            {
                //Se validan las propiedades de la clase
                var validator = new ExampleValidator();
                var resultValidation = validator.Validate(example);

                if (!resultValidation.IsValid)
                {
                    var problemDetails = _problemDetailModel.GetInvalidParams(resultValidation, HttpContext.Request.Path);
                    return BadRequest(problemDetails);
                }
                //Se utiliza repository para crear registro
                var result = _exampleRepository.Create(example);
                return Created(HttpContext.Request.Path, result);
            }
            catch (Exception ex)
            {
                var problemDetailModel = _problemDetailModel.GetErrorInternalServerError(ex.Message, HttpContext.Request.Path);
                return StatusCode(StatusCodes.Status500InternalServerError, problemDetailModel);
            }
        }

        /// <summary>
        /// Método que actualiza un objeto ejemplo
        /// </summary>
        /// <param name="example">Objeto ejemplo a actualizar.</param>
        /// <response code="204">No Content - Actualización exitosa de un objeto ejemplo.</response>
        /// <response code="400">Bad Request - Datos enviados no son válidos.</response>
        /// <response code="404">Not Found - No se encontraron resultados para el id ingresado.</response>
        /// <response code="500">Internal Server Error - Falla a nivel de acceso a datos o aplicación.</response>
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status400BadRequest)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status404NotFound)]
        [ProducesResponseType(typeof(ProblemDetailsModel), StatusCodes.Status500InternalServerError)]
        public ActionResult Put([FromBody]ExampleDto example)
        {
            try
            {
                //Se validan las propiedades de la clase
                var validator = new ExampleValidator();
                var resultValidation = validator.Validate(example);

                if (!resultValidation.IsValid)
                {
                    //Se utiliza un método de la clase ValidationTools para generar la clase requeridad en caso de error: ProblemDetailsModel
                    var problemDetails = _problemDetailModel.GetInvalidParams(resultValidation, HttpContext.Request.Path);
                    return BadRequest(problemDetails);
                }
                //Se realiza una búsqueda por Id, para verificar que extista el registro
                var exampleResult = _exampleRepository.FindById(example.Id);

                //En caso de no encontrar un registro, se indica error Not Found
                if (exampleResult == null)
                {
                    return NotFound(_problemDetailModel.GetErrorNotFound(
                        "No se encontraron resultados para el id consultado.",
                        HttpContext.Request.Path));
                }
                //Se utiliza repository para actualizar registro
                var result = _exampleRepository.Update(example);
                if (result)
                {
                    return NoContent();
                }
                else
                {
                    var problemDetailModel = _problemDetailModel.GetErrorInternalServerError("No fue posible actualizar el registro.", HttpContext.Request.Path);
                    return StatusCode(StatusCodes.Status500InternalServerError, problemDetailModel);
                }
            }
            catch (Exception ex)
            {
                var problemDetailModel = _problemDetailModel.GetErrorInternalServerError(ex.Message, HttpContext.Request.Path);
                return StatusCode(StatusCodes.Status500InternalServerError, problemDetailModel);
            }
        }
    }
}