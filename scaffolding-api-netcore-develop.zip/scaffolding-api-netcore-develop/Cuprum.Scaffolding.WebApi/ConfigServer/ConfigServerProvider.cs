﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cuprum.Scaffolding.WebApi.ConfigServer
{

    public class ConfigServerProvider
    {
        public string ConnectionString { get; set; }
    }
}
