﻿namespace Cuprum.Scaffolding.WebApi.Helper
{
    /// <summary>
    /// Clase dedicada a contener los datos del appsettings.json
    /// </summary>
    public class AppSettingsHelper
    {
        /// <summary>
        /// Url base de SM
        /// </summary>
        public string BaseUrlSecurityManager { get; set; }
        /// <summary>
        /// Recurso de validacion de SM
        /// </summary>
        public string UriValidationSecurityManager { get; set; }

        /// <summary>
        /// Parametro de ejemplo
        /// </summary>
        public string ParameterOne { get; set; }
        /// <summary>
        /// Parametro de ejemplo
        /// </summary>
        public string ParameterTwo { get; set; }
    }
}
