﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using Cuprum.Scaffolding.Infraestructure;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.PlatformAbstractions;
using HealthChecks.UI.Client;
using Cuprum.Scaffolding.WebApi.Helper;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using System.Threading.Tasks;
using System.Threading;
using Pivotal.Discovery.Client;
using Cuprum.Scaffolding.WebApi.ConfigServer;
using DependencyResolver = Cuprum.Scaffolding.WebApi.Helper.DependencyResolver;
using Microsoft.Extensions.Options;
using Cuprum.Scaffolding.Infraestructure.Repository;
using Cuprum.Scaffolding.Domain.Contracts;
using Cuprum.Scaffolding.Domain.DataTransferObject.Error;

namespace Cuprum.Scaffolding.WebApi
{
    /// <summary>
    /// Clase de configuración inicial de la aplicación
    /// </summary>
    public class Startup
    {
        #region [Methods Startup & Configuration]
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="configuration">Inyeccion de dependencia</param>
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        /// <summary>
        /// Representa un conjunto de propiedades de configuración de la aplicación 
        /// </summary>
        public IConfiguration Configuration { get; }

        /// <summary>
        /// Metodo en donde se configura los servicios de la aplicación
        /// </summary>
        /// <param name="services"></param>
        public void ConfigureServices(IServiceCollection services)
        {
            
            services.AddDiscoveryClient(Configuration);
            services.Configure<ConfigServerProvider>(Configuration);
            services.Configure<RouteOptions>(options => options.LowercaseUrls = true);
            services.AddCors();
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddHealthChecks()
                .AddSqlServer(
                              connectionString: Configuration.GetConnectionString("BD_ScaffoldingConnection"),
                              healthQuery: "SELECT 1;",
                              name: "sql",
                              failureStatus: HealthStatus.Degraded,
                              tags: new string[] { "db", "sql", "sqlserver" })
                .AddCheck<RandomHealthCheck>("random");
            services.AddHealthChecksUI();
            DependencyInjection(services);
            AddSwaggerExplorer(services);
            ConfigurationApp(services);
        }
        /// <summary>
        /// Metodo de configuracion de la aplicacion
        /// </summary>
        /// <param name="app"></param>
        /// <param name="env"></param>
        /// <param name="loggerFactory"></param>
        /// <param name="provider"></param>
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IApiVersionDescriptionProvider provider)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }
            app.UseSwagger();
            app.UseSwaggerUI(
                options =>
                {
                    foreach (var description in provider.ApiVersionDescriptions)
                    {
                        options.SwaggerEndpoint($"/swagger/{description.GroupName}/swagger.json", description.GroupName.ToUpperInvariant());
                    }
                    options.RoutePrefix = string.Empty;
                });
            app.UseCors(
                options => options.WithOrigins("*").AllowAnyMethod().AllowAnyHeader()
            );
            app.UseHttpsRedirection();
            app.UseMvc();
            app.UseHealthChecks("/healthz", new HealthCheckOptions()
            {
                Predicate = _ => true,
                ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
            });
            app.UseHealthChecksUI(setup => { setup.ApiPath = "/health"; setup.UIPath = "/healthcheckui"; } );
        }
        #endregion

        #region [Dependency Injection]
        /// <summary>
        /// Metodo el cual se indican las implementaciones a los contratos
        /// </summary>
        /// <param name="services"></param>
        public void DependencyInjection(IServiceCollection services)
        {
            //se agregan dependencias
            services.AddSingleton<IExampleRepository, ExampleRepository>();
            services.AddSingleton<IProblemDetailsModel, ProblemDetailsModel>();
        }
        #endregion

        #region [Configuration App]
        /// <summary>
        /// Metodo que obtiene los datos del archivo appsettings.json para configurar la aplicacion
        /// </summary>
        /// <param name="services"></param>
        public void ConfigurationApp(IServiceCollection services)
        {
            //Obtener la cadena de conexión de base de datos
            services.Configure<ConnectionStringOption>(options =>
            {
                options.ConnectionString = Configuration.GetConnectionString("BD_ScaffoldingConnection");

                // Obtener String de conexión desde Config Server
                // options.ConnectionString = DependencyResolver.ServiceProvider.GetService<IOptions<ConfigServerProvider>>().Value.ConnectionString;
            });
            //En caso de obtener las configuraciones de el archivo appsettings.json
            services.Configure<AppSettingsHelper>(options =>
            {
                options.BaseUrlSecurityManager = Configuration["Routes:BaseUrlSecurityManager"].ToString();
                options.UriValidationSecurityManager = Configuration["Routes:UriValidationSecurityManager"].ToString();
                options.ParameterOne = Configuration["Parameters:ParameterOne"].ToString();
                options.ParameterTwo = Configuration["Parameters:ParameterTwo"].ToString();
            });
            Scaffolding.Infraestructure.DependencyResolver.ServiceProvider = services.BuildServiceProvider();
            Scaffolding.WebApi.Helper.DependencyResolver.ServiceProvider = services.BuildServiceProvider();
        }
        #endregion

        #region [Methods Swagger]
        /// <summary>
        /// Metodo que agrega los servicios de swagger para utilizarlo en el proyecto
        /// </summary>
        /// <param name="services"></param>
        public void AddSwaggerExplorer(IServiceCollection services)
        {
            var basePath = PlatformServices.Default.Application.ApplicationBasePath;
            var fileName = typeof(Startup).GetTypeInfo().Assembly.GetName().Name + ".xml";
            services.AddSwaggerGen(options =>
            {
                var provider = services.BuildServiceProvider().GetRequiredService<IApiVersionDescriptionProvider>();
                foreach (var description in provider.ApiVersionDescriptions)
                {
                    options.SwaggerDoc(description.GroupName, CreateInfoForApiVersion(description));
                }
                //options.OperationFilter<SwaggerDefaultValues>();
                options.IncludeXmlComments(Path.Combine(basePath, fileName));
            });
            services.AddVersionedApiExplorer(
               options =>
               {
                   options.GroupNameFormat = "'v'VVV";
                   options.SubstituteApiVersionInUrl = true;
               });
            services.AddApiVersioning(options => {
                options.ReportApiVersions = true;
            });
        }

        /// <summary>
        /// Metodo que obtiene informacion de la api
        /// </summary>
        /// <param name="description">Objeto que contiene datos de la version de la api</param>
        /// <returns></returns>
        static Info CreateInfoForApiVersion(ApiVersionDescription description)
        {
            var info = new Info()
            {
                Title = $"API {description.ApiVersion}",
                Version = description.ApiVersion.ToString(),
                Description = "Api",
            };

            if (description.IsDeprecated)
            {
                info.Description += " Esta versión de la API está deprecada.";
            }

            return info;
        }
        #endregion
    }

    #region [Class Random HealthCheck]
    /// <summary>
    /// Clase RandomHealthCheck
    /// </summary>
    public class RandomHealthCheck : IHealthCheck
    {
        /// <summary>
        /// Método CheckHealthAsync
        /// </summary>
        /// <param name="context"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken)
        {
            if (DateTime.UtcNow.Minute % 2 == 0)
            {
                return Task.FromResult(HealthCheckResult.Healthy());
            }

            return Task.FromResult(HealthCheckResult.Unhealthy(description: "failed"));
        }
    }
    #endregion
}
