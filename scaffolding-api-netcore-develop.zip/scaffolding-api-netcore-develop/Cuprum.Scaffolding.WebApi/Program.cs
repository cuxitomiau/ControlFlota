﻿using System;
using System.IO;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;
using Pivotal.Extensions.Configuration.ConfigServer;
using Steeltoe.Extensions.Configuration.ConfigServer;
using Steeltoe.Extensions.Logging;
namespace Cuprum.Scaffolding.WebApi
{
    /// <summary>
    /// Clase de configuración inicial
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Metodo inicial
        /// </summary>
        /// <param name="args"></param>
        public static void Main(string[] args)
        {
            var appBasePath = Directory.GetCurrentDirectory();
            NLog.GlobalDiagnosticsContext.Set("appbasepath", appBasePath);
            var logger = NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
            try
            {
                logger.Debug("init main");
                BuildWebHost(args).Run();
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                NLog.LogManager.Shutdown();
            }
        }
        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)

            .ConfigureAppConfiguration((webHostBuilderContext, configurationBuilder) => {

                var hostingEnvironment = webHostBuilderContext.HostingEnvironment;
                configurationBuilder.AddConfigServer(hostingEnvironment);
            })
            .UseKestrel()
            .UseContentRoot(Directory.GetCurrentDirectory())
            .UseUrls("http://+:5000/")
            .UseIISIntegration()
            .UseStartup<Startup>()
            .ConfigureLogging(logging =>
            {
                logging.ClearProviders();
                logging.SetMinimumLevel(LogLevel.Trace);
                // Add Steeltoe Dynamic Logging Provider
                logging.AddDynamicConsole();
            }).UseNLog()
            .Build();
    }
}
