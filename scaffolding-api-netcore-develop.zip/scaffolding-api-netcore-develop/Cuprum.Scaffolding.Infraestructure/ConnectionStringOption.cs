﻿namespace Cuprum.Scaffolding.Infraestructure
{
    /// <summary>
    /// Clase dedicada a contener la cadena de conexión del appsettings.json
    /// </summary>
    public class ConnectionStringOption
    {
        /// <summary>
        /// Cadena de conexión de base de datos
        /// </summary>
        public string ConnectionString { get; set; }
    }
}
