﻿using System;
using System.Collections.Generic;
using System.Text;
//using Cuprum.Scaffolding.Infraestructure.Entities;
namespace Cuprum.Scaffolding.Infraestructure.Repository
{
    /// <summary>
    /// Clase dedicada a crear una nueva instancia del contexto
    /// </summary>
    /// <typeparam name="TEntity">Entidad de base de datos</typeparam>
    public class FactoryRepository<TEntity> where TEntity : class
    {
        //public static DbContext BdTrazabilidadContext => new BD_ScaffoldingContext();
        //public static IRepository<TEntity> CreateRepositoryGeneric()
        //{
        //    return new Repository<TEntity>(BdTrazabilidadContext);
        //}
    }
}
