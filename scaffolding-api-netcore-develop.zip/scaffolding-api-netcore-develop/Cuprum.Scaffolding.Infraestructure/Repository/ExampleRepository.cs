﻿using Cuprum.Scaffolding.Domain.Contracts;
using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.Infraestructure.Repository
{
    public class ExampleRepository : IExampleRepository
    {
        /// <summary>
        /// Método que encuentra objetos ejemplo por id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>ExampleInfoDto</returns>
        public ExampleInfoDto FindById(int id)
        {
            return new ExampleInfoDto();
        }

        /// <summary>
        /// Método que crea objeto ejemplo
        /// </summary>
        /// <param name="example"></param>
        /// <returns>Integer</returns>
        public int Create(ExampleDto example)
        {
            return 1;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="example"></param>
        /// <returns></returns>
        public bool Update(ExampleDto example)
        {
            return true;
        }
    }
}
