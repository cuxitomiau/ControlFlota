﻿using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Cuprum.Scaffolding.Infraestructure.Mapper
{
    /// <summary>
    /// Clase Mapper Example. Normalmente en el desarrollo de APIs no es necesario utilizar Mapper, pero en el caso de ser requerido, se deja esta clase como ejemplo.
    /// </summary>
    public static class ExampleMapper
    {
        /// <summary>
        /// Mapea una lista de Entities a una lista de DTO
        /// </summary>
        /// <param name="entities"></param>
        /// <returns>ExampleinfoDto</returns>
        public static IList<ExampleInfoDto> ToDto(this IList<ExampleEntity> entities)
        {
            return entities.Select(ToDto).ToList();
        }

        /// <summary>
        /// Mapea una Entidad a un DTO
        /// </summary>
        /// <param name="entity"></param>
        /// <returns>ExampleInfoDto</returns>
        public static ExampleInfoDto ToDto(this ExampleEntity entity)
        {
            return new ExampleInfoDto
            {
                Id = entity.IdRegistro
            };
        }
    }
}
