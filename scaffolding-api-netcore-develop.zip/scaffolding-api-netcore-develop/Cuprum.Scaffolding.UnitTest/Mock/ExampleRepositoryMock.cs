﻿using Cuprum.Scaffolding.Domain.Contracts;
using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cuprum.Scaffolding.UnitTest.Mock
{
    public class ExampleRepositoryMock : IExampleRepository
    {
        public int Create(ExampleDto example)
        {
            if (example.Id == 1)
            {
                return 1;
            }
            else if (example.Id == 3)
            {
                throw new Exception("Error controlado");
            }
            throw new NotImplementedException();
        }

        public ExampleInfoDto FindById(int id)
        {
            if (id == 5)
            {
                return null;
            }
            if (id == 999999999)
            {
                throw new Exception("Error controlado");
            }
            return new ExampleInfoDto
            {
                Id = id
            };
        }

        public bool Update(ExampleDto example)
        {
            if (example.Id == 1)
            {
                return true;
            }
            if(example.Id == 4)
            {
                throw new Exception("Error controlado");
            }
            if (example.Id == 6)
            {
                return false;
            }
            return true;
        }
    }
}
