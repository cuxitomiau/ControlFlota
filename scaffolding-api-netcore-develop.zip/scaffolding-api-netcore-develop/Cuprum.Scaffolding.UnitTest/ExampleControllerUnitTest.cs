using Cuprum.Scaffolding.Domain.Contracts;
using Cuprum.Scaffolding.Domain.DataTransferObject.Error;
using Cuprum.Scaffolding.Domain.DataTransferObject.Example;
using Cuprum.Scaffolding.UnitTest.Mock;
using Cuprum.Scaffolding.WebApi.V1.Controllers;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Net.Http;

namespace Cuprum.Scaffolding.UnitTest
{
    [TestClass]
    public class ExampleControllerUnitTest
    {
        private ExampleController _exampleController;

        [TestInitialize]
        public void Setup()
        {
            IExampleRepository _exampleRepository;
            _exampleRepository = new ExampleRepositoryMock();

            IProblemDetailsModel _problemDetailModel = new ProblemDetailsModel();

            _exampleController = new ExampleController(_exampleRepository, _problemDetailModel)
            {
                ControllerContext = new ControllerContext
                {
                    HttpContext = new DefaultHttpContext()
                }
            };
            _exampleController.ControllerContext.HttpContext.Request.Headers["device-id"] = "20317";
        }

        #region [GET]
        [TestMethod]
        public void Example_GetById_ReturnOk()
        {
            var id = 123;
            var resultado = _exampleController.Get(id);
            Assert.AreEqual(StatusCodes.Status200OK, ((ObjectResult)resultado.Result).StatusCode);
        }

        [TestMethod]
        public void Example_GetById_ReturnNotFound()
        {
            int id = 5;
            var resultado = _exampleController.Get(id);
            Assert.AreEqual(StatusCodes.Status404NotFound, ((ObjectResult)resultado.Result).StatusCode);
        }

        [TestMethod]
        public void Example_GetById_ReturnInternalServerError()
        {
            int id = 999999999;
            var resultado = _exampleController.Get(id);
            Assert.AreEqual(StatusCodes.Status500InternalServerError, ((ObjectResult)resultado.Result).StatusCode);
        }
        #endregion

        #region [POST]
        [TestMethod]
        public void Example_Post_ReturnCreated()
        {
            var model = new ExampleDto
            {
                Id = 1
            };
            var resultado = _exampleController.Post(model);
            Assert.AreEqual(StatusCodes.Status201Created, ((ObjectResult)resultado.Result).StatusCode);
        }

        [TestMethod]
        public void Example_Post_ReturnBadRequest()
        {
            var model = new ExampleDto
            {
                Id = 0
            };
            var resultado = _exampleController.Post(model);
            Assert.AreEqual(StatusCodes.Status400BadRequest, ((ObjectResult)resultado.Result).StatusCode);
        }

        [TestMethod]
        public void Example_Post_ReturnInternalServerError()
        {
            var model = new ExampleDto
            {
                Id = 3
            };
            var resultado = _exampleController.Post(model);
            Assert.AreEqual(StatusCodes.Status500InternalServerError, ((ObjectResult)resultado.Result).StatusCode);
        }
        #endregion

        #region [PUT]
        [TestMethod]
        public void Example_Put_ReturnNoContent()
        {
            var model = new ExampleDto
            {
                Id = 1
            };

            var resultado = _exampleController.Put(model);
            Assert.AreEqual(StatusCodes.Status204NoContent, ((StatusCodeResult)resultado).StatusCode);
        }

        [TestMethod]
        public void Example_Put_ReturnBadRequest()
        {
            var model = new ExampleDto()
            {
                Id = 0
            };

            var resultado = _exampleController.Put(model);
            Assert.AreEqual(StatusCodes.Status400BadRequest, ((ObjectResult)resultado).StatusCode);
        }

        [TestMethod]
        public void Example_Put_ReturnNotFound()
        {
            var model = new ExampleDto()
            {
                Id = 5
            };

            var resultado = _exampleController.Put(model);
            Assert.AreEqual(StatusCodes.Status404NotFound, ((ObjectResult)resultado).StatusCode);
        }

        [TestMethod]
        public void Example_Put_ReturnInternalServerError()
        {
            var model = new ExampleDto()
            {
                Id = 4
            };
            var resultado = _exampleController.Put(model);
            Assert.AreEqual(StatusCodes.Status500InternalServerError, ((ObjectResult)resultado).StatusCode);
        }

        [TestMethod]
        public void Example_Put_ReturnInternalServerError_UpdateFalse()
        {
            var model = new ExampleDto()
            {
                Id = 6
            };
            var resultado = _exampleController.Put(model);
            Assert.AreEqual(StatusCodes.Status500InternalServerError, ((ObjectResult)resultado).StatusCode);
        }
        #endregion
    }
}
