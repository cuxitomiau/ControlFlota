# Scaffolding Oficial Web API .NET Core

## Incluye:
* Versión de NET Core 2.2
* Inyección de Dependencias
* Patrón Repository
* Swagger y Versionado de Swagger
* Proyecto Test Unitario
* Estructura Proyectos Base
* Extensión de IEnumerable, para realizar paginación de listas.
* Check Health